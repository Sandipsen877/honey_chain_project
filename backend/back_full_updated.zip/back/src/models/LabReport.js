import mongoose from "mongoose";
const { Schema } = mongoose;

const LabReportSchema = new Schema(
  {
    batch: { type: Schema.Types.ObjectId, ref: "Batch", required: true },
    labName: { type: String, default: "KVIC Regional Testing Lab (mock)" },
    sampleId: { type: String, required: true },
    testedDate: { type: Date },

    // Standard honey quality parameters
    moisturePct: { type: Number },
    hmfMgPerKg: { type: Number }, // Hydroxymethylfurfural - heating/age/adulteration marker
    reducingSugarPct: { type: Number },
    sucrosePct: { type: Number },
    fructoseGlucoseRatio: { type: Number },
    c4SugarTestResult: { type: String, enum: ["pass", "fail", "not_tested"], default: "not_tested" },
    diastaseActivity: { type: Number }, // enzyme activity, freshness indicator
    pollenFloralSource: { type: String }, // lab-verified floral source

    overallResult: { type: String, enum: ["pass", "fail", "pending"], default: "pending" },
    isMock: { type: Boolean, default: true },
    verifiedBy: { type: Schema.Types.ObjectId, ref: "KvicAdmin" }, // set when a real KVIC admin files the report
  },
  { timestamps: true }
);

// Not unique anymore - a batch can accumulate several reports over time
// (re-tests, corrections, etc.) and every one of them is kept.
LabReportSchema.index({ batch: 1, createdAt: -1 });

export default mongoose.model("LabReport", LabReportSchema);
